# GroopieTracker

## Structure du projet:

- API:
  -
    - Init des variables `ApiInit.go`
    - stockage des variables ds le file `Variables.go`

- Front:
  -
    -
- Location:
  -
    -